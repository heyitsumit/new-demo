# Dean's Place — Simple Static Website

This is intentionally a simple static website. There is **no backend**, database, login, API, or reservation system.

## GitHub Pages

1. Create a GitHub repository, for example `deans-place`.
2. Upload `index.html`.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`.
6. Save.
7. Wait for GitHub Pages to deploy.

The site can then be opened at:
`https://YOUR-USERNAME.github.io/deans-place/`

## Notes
- Replace the external food photos with the restaurant's approved images before production.
- The phone button uses `tel:` and the directions button opens Google Maps.
- No backend is required.
